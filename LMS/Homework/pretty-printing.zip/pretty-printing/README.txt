Môi trường/ngôn ngữ: Python

Chạy chương trình:
- python pretty-printing.py
- Sau đó, nhập độ dài của dòng L

File đầu vào: input.txt
Định dạng input:
- Các từ phải có độ dài nhỏ hơn bằng L.
- Các câu văn của 1 đoạn văn nằm trên cùng 1 dòng.
- Các đoạn văn phân cách nhau bởi 2 dấu xuống dòng.

File đầu ra: output.txt